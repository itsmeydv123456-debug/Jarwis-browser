import 'package:flutter/material.dart';

import 'package:webview_flutter/webview_flutter.dart';

void main() {

  runApp(const JarwisBrowser());

}

class JarwisBrowser extends StatelessWidget {

  const JarwisBrowser({super.key});

  @override

  Widget build(BuildContext context) {

    return MaterialApp(

      title: 'Jarwis',

      theme: ThemeData(

        primarySwatch: Colors.blue,

        useMaterial3: true,

      ),

      home: const WebViewScreen(),

    );

  }

}

class WebViewScreen extends StatefulWidget {

  const WebViewScreen({super.key});

  @override

  State<WebViewScreen> createState() => _WebViewScreenState();

}

class _WebViewScreenState extends State<WebViewScreen> {

  late final WebViewController _controller;

  var _currentUrl = 'https://www.bing.com';

  final TextEditingController _urlController = TextEditingController();

  @override

  void initState() {

    super.initState();

    _urlController.text = _currentUrl;

    _controller = WebViewController()

      ..setJavaScriptMode(JavaScriptMode.unrestricted)

      ..setBackgroundColor(const Color(0x00000000))

      ..setNavigationDelegate(

        NavigationDelegate(

          onProgress: (int progress) {},

          onPageStarted: (String url) {

            setState(() {

              _currentUrl = url;

              _urlController.text = url;

            });

          },

          onPageFinished: (String url) { // ← यहाँ बदलाव है!

            setState(() {

              _currentUrl = url;

            });

          },

        ),

      )

      ..loadRequest(Uri.parse(_currentUrl));

  }

  @override

  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(

        title: const Text('Jarwis Browser'),

        backgroundColor: Colors.blue,

      ),

      body: Column(

        children: [

          Container(

            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),

            color: Colors.grey[200],

            child: Row(

              children: [

                IconButton(

                  icon: const Icon(Icons.arrow_back),

                  onPressed: () async {

                    if (await _controller.canGoBack()) {

                      _controller.goBack();

                    }

                  },

                ),

                IconButton(

                  icon: const Icon(Icons.arrow_forward),

                  onPressed: () async {

                    if (await _controller.canGoForward()) {

                      _controller.goForward();

                    }

                  },

                ),

                IconButton(

                  icon: const Icon(Icons.refresh),

                  onPressed: () {

                    _controller.reload();

                  },

                ),

                Expanded(

                  child: TextField(

                    controller: _urlController,

                    decoration: const InputDecoration(

                      hintText: 'Enter URL',

                      contentPadding: EdgeInsets.symmetric(vertical: 8),

                      border: InputBorder.none,

                      filled: true,

                      fillColor: Colors.white,

                    ),

                    onSubmitted: (value) {

                      String url = value.trim();

                      if (!url.startsWith('http')) {

                        url = 'https://$url';

                      }

                      _controller.loadRequest(Uri.parse(url));

                    },

                  ),

                ),

              ],

            ),

          ),

          Expanded(

            child: WebViewWidget(controller: _controller),

          ),

        ],

      ),

    );

  }

}