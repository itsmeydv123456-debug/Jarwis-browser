package com.jarwish.browser

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
